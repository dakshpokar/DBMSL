package com.dakshpokar.Assign2;

import java.math.BigInteger;

public class Professor {
	String fname, lname, designation, doj, email, city;
	int dept_id, salary;
	long phone;
	
	public Professor(String fname, String lname, int dept_id, String designation, int salary, String doj, String email, long phone, String city)
	{
		this.fname = fname;
		this.lname = lname;
		this.dept_id = dept_id;
		this.designation = designation;
		this.doj = doj;
		this.email = email;
		this.phone = phone;
		this.city = city;
	}
	public Professor()
	{
		
	}
	public String getCity() {
		return city;
	}
	public int getDept_id() {
		return dept_id;
	}
	public String getDesignation() {
		return designation;
	}
	public String getDoj() {
		return doj;
	}
	public String getEmail() {
		return email;
	}
	public String getFname() {
		return fname;
	}
	public String getLname() {
		return lname;
	}
	public long getPhone() {
		return phone;
	}
	public int getSalary() {
		return salary;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
}
